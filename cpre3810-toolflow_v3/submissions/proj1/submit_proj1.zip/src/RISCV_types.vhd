-------------------------------------------------------------------------
-- Author: Braedon Giblin
-- Date: 2022.02.12
-- Files: RISCV_types.vhd
-------------------------------------------------------------------------
-- Description: This file contains a skeleton for some types that 381 students
-- may want to use. This file is guarenteed to compile first, so if any types,
-- constants, functions, etc., etc., are wanted, students should declare them
-- here.
-------------------------------------------------------------------------

library IEEE;
use IEEE.std_logic_1164.all;

package RISCV_types is

  -- Example Constants. Declare more as needed

  --General types

  -- Example record type. Declare whatever types you need here
  type control_t is record
    reg_wr : std_logic;
    reg_to_mem : std_logic;
  end record control_t;

  type t_bus_4x32 is array (3 downto 0) of std_logic_vector(31 downto 0);
  type t_bus_32x32 is array (31 downto 0) of std_logic_vector(31 downto 0);

end package RISCV_types;

package body RISCV_types is
  -- Probably won't need anything here... function bodies, etc.
end package body RISCV_types;
