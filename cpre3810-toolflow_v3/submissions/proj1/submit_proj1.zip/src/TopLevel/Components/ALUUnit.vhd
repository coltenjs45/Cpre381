library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.numeric_std.all;
use work.RISCV_types.all;

entity ALUUnit is
 generic (WIDTH : integer := 32);
 port(
    Alucontrol : in std_logic_vector(3 downto 0);
    flag_mux : in std_logic_vector(1 downto 0);
    input_A : in std_logic_vector (WIDTH-1 downto 0);
    input_B : in std_logic_vector (WIDTH-1 downto 0);
    output_result : out std_logic_vector (WIDTH-1 downto 0);
    overflowFlag: out std_logic;
    flag : out std_logic
 );
 end ALUUnit;

 architecture structural of ALUUnit is

    component nBit_ALU
        port(nAdd_Sub		: in std_logic;
            input_A 		: in std_logic_vector(WIDTH-1 downto 0);
            input_B 		: in std_logic_vector(WIDTH-1 downto 0);
            output_Sum	: out std_logic_vector(WIDTH-1 downto 0);
            output_Carry     : out std_logic;
            output_Overflow : out std_logic
            );
    end component;

    component and_32bit
        port(
            i_D0 : in std_logic_vector(WIDTH-1 downto 0);
            i_D1 : in std_logic_vector (WIDTH-1 downto 0);
            o_O : out std_logic_vector(WIDTH-1 downto 0)
        );
    end component;

    component xor_32bit
        port(
            i_D0 : in std_logic_vector(WIDTH-1 downto 0);
            i_D1 : in std_logic_vector (WIDTH-1 downto 0);
            o_O : out std_logic_vector(WIDTH-1 downto 0)
        );
    end component;

    component xorg2
        port(
            i_A   : in std_logic;
            i_B   : in std_logic;
            o_F   : out std_logic);
    end component;
        

    component or_32bit
        port(
            i_D0 : in std_logic_vector(WIDTH-1 downto 0);
            i_D1 : in std_logic_vector (WIDTH-1 downto 0);
            o_O : out std_logic_vector(WIDTH-1 downto 0)
        );
    end component;

    component mux32x4t1 is
        port(sel        : in std_logic_vector(1 downto 0);
        bus_in		  : in t_bus_4x32;
        o_output 	: out std_logic_vector(31 downto 0));
    end component;

    component mux2t1_2 is 
        port(
            i_S          : in std_logic;
            i_D0         : in std_logic_vector(1 downto 0);
            i_D1         : in std_logic_vector(1 downto 0);
            o_O          : out std_logic_vector(1 downto 0)
            );
    end component;

    component mux4t1
        port(
            i_D0 : in std_logic;
            i_D1 : in std_logic;
            i_D2 : in std_logic;
            i_D3 : in std_logic;
            i_S  : in std_logic_vector(1 downto 0);
            o_Y  : out std_logic
        );
    end component;

    component nor_32t1bit is
        port(
            i_D : in std_logic_vector(WIDTH-1 downto 0);
            o_O : out std_logic
        );
    end component;

    signal output_bus : t_bus_4x32;
    signal mux_control4t1, mux_control2t1  :std_logic_vector(1 downto 0);
    signal finalResult : std_logic_vector(WIDTH-1 downto 0);
    signal neg, ovf, carry, zero, slt_flag : std_logic;

    begin
        mux_control2t1 <= Alucontrol(1 downto 0);
        neg <= finalResult(31);

          andUnit : and_32bit 
          port map(
            i_D0 => input_A,
            i_D1 => input_B,
            o_O => output_bus(0)
          );

          orUnit : or_32bit
        port map(
            i_D0 => input_A,
            i_D1 => input_B,
            o_O  => output_bus(1)
        );

        xorUnit : xor_32bit
        port map(
            i_D0 => input_A,
            i_D1 => input_B,
            o_O  => output_bus(2)
        );
        norUnit : nor_32t1bit
        port map(
        i_D => finalResult,
        o_O => zero
        );


        addsub : nBit_ALU
        port map(
            nAdd_Sub     => Alucontrol(2), 
            input_A      => input_A,
            input_B      => input_B,
            output_Sum   => output_bus(3),
            output_Carry => carry,
            output_Overflow => ovf
        );

        muxbeforeresult : mux2t1_2
        port map(
            i_S => Alucontrol(2),
            i_D0 => mux_control2t1,
            i_D1 => "11",
            o_O => mux_control4t1
        );

        muxResult : mux32x4t1
        port map(
            sel      => mux_control4t1,
            bus_in   => output_bus,
            o_output => finalResult
        );

        slt_xor : xorg2
        port map(
            i_A => neg,
            i_B => ovf,
            o_F => slt_flag
        );

        Flags_mux: mux4t1
        port map(
            i_D0 => neg,
            i_D1 => slt_flag,
            i_D2 => carry,
            i_D3 => zero,
            i_S  => flag_mux,
            o_Y => flag
        );

        overflowFlag <= '0';
        output_result <= finalResult;
    end structural;






